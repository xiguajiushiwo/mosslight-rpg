(function (root) {
  'use strict';
  const W = 2304, H = 1728, SAVE_VERSION = 1;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  function seeded(seed) { return () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; }; }
  const NPCS = [
    { id: 'keeper', name: '守灯人 · 洛恩', x: 550, y: 1240, type: 'keeper' },
    { id: 'merchant', name: '草药师 · 米娅', x: 800, y: 1300, type: 'merchant' }
  ];
  const CHESTS = [
    { id: 'grove', x: 430, y: 480, stone: true, name: '西林萤石' },
    { id: 'river', x: 1550, y: 1160, stone: true, name: '河畔萤石' },
    { id: 'ruin', x: 1410, y: 360, stone: true, name: '旧塔萤石' },
    { id: 'village', x: 335, y: 1370, stone: false, name: '旅人的行囊' },
    { id: 'northeast', x: 1630, y: 650, stone: false, name: '遗落的箱子' }
  ];
  const BEACON = { id: 'beacon', x: 2010, y: 235, name: '古林灯塔', type: 'beacon' };
  const FIRE = { x: 630, y: 1260 };
  const HOUSE_RECTS = [
    { x: 350, y: 1130, w: 120, h: 85 }, { x: 710, y: 1140, w: 130, h: 85 },
    { x: 450, y: 1440, w: 130, h: 90 }
  ];
  function nearPath(x, y, extra = 0) {
    return (Math.abs(y - 1330) < 80 + extra && x < 1150) ||
      (Math.abs(x - 1135) < 65 + extra && y > 450) ||
      (Math.abs(y - 1050) < 55 + extra && x > 1110 && x < 1640) ||
      (Math.abs(y - 485) < 60 + extra && x > 400 && x < 1990) ||
      (Math.abs(x - 2005) < 55 + extra && y < 690) ||
      (Math.abs(x - 1410) < 55 + extra && y > 320 && y < 500);
  }
  function makeScenery() {
    const rng = seeded(70621), trees = [], rocks = [], flowers = [];
    const excludes = [...NPCS, ...CHESTS, FIRE, BEACON, { x: 610, y: 1340 }];
    for (let i = 0; i < 560; i++) {
      const x = 50 + rng() * (W - 100), y = 50 + rng() * (H - 100);
      if (nearPath(x, y, 23) || (y > 735 && y < 925) || (x > 1780 && y < 700) ||
        (x > 260 && x < 910 && y > 1080 && y < 1540) || excludes.some(p => Math.hypot(p.x - x, p.y - y) < 100)) continue;
      if (trees.some(p => Math.hypot(p.x - x, p.y - y) < 50)) continue;
      trees.push({ x: Math.round(x), y: Math.round(y), size: 0.78 + rng() * .6, variant: Math.floor(rng() * 4) });
    }
    for (let i = 0; i < 100; i++) {
      const x = 70 + rng() * (W - 140), y = 70 + rng() * (H - 140);
      if (nearPath(x, y, 35) || (y > 735 && y < 925) || (x > 1780 && y < 710) ||
        (x < 920 && y > 1050 && y < 1570) || excludes.some(p => Math.hypot(p.x-x,p.y-y)<85)) continue;
      rocks.push({ x, y, size: 9 + rng() * 12 });
    }
    for (let i = 0; i < 1700; i++) flowers.push({ x: rng() * W, y: rng() * H, color: Math.floor(rng() * 8), size: rng() });
    return { trees, rocks, flowers };
  }
  const SCENERY = makeScenery();
  function inWater(x, y, r = 0) { return y + r > 775 && y - r < 880 && !(x - r > 1065 && x + r < 1205); }
  function solidAt(x, y, r, quest) {
    if (x < 40+r || x > W-40-r || y < 50+r || y > H-40-r || inWater(x,y,r)) return true;
    if (quest < 2 && x+r > 1810 && x-r < 2210 && y+r > 130 && y-r < 650) return true;
    if (HOUSE_RECTS.some(o => x+r>o.x && x-r<o.x+o.w && y+r>o.y && y-r<o.y+o.h)) return true;
    if (SCENERY.trees.some(o => Math.hypot(x-o.x,y-o.y)<r+12*o.size)) return true;
    return SCENERY.rocks.some(o => Math.hypot(x-o.x,y-o.y)<r+o.size*.7);
  }
  const ENEMY_SEEDS = [
    ['s1','slime',1020,1180],['s2','slime',1220,1120],['s3','slime',1470,1230],['s4','slime',1620,1090],
    ['s5','slime',980,980],['s6','slime',1250,525],['s7','slime',990,600],['s8','slime',690,520],
    ['s9','slime',410,630],['s10','slime',510,400],['s11','slime',1250,400],['s12','slime',1500,460],
    ['w1','wolf',1580,990],['w2','wolf',1540,580],['w3','wolf',820,460],['w4','wolf',1370,300],
    ['w5','wolf',1730,485],['w6','wolf',1900,690],['w7','wolf',1500,1380],['boss','boss',2005,415]
  ];
  function makeEnemy([id,type,x,y]) {
    const boss = type==='boss', wolf=type==='wolf';
    return { id, type, x, y, homeX:x, homeY:y, r:boss?40:wolf?17:16, hp:boss?650:wolf?76:46,
      maxHp:boss?650:wolf?76:46, speed:boss?35:wolf?83:49, damage:boss?25:wolf?16:11,
      xp:boss?160:wolf?25:16, coins:boss?70:wolf?9:5, cooldown:1.2, windup:0, attackX:0,attackY:0,
      flash:0, alive:true, phase:0, seed:x+y };
  }
  class Game {
    constructor() {
      this.player={x:610,y:1340,r:11,hp:100,maxHp:100,mp:60,maxMp:60,level:1,xp:0,coins:0,potions:3,
        sword:false,angle:-Math.PI/2,attackCooldown:0,spellCooldown:0,dashCooldown:0,dashTime:0,
        dashX:0,dashY:0,invulnerable:0,walk:0,moving:false};
      this.quest=0; this.stones=0; this.opened=new Set(); this.killed=new Set();
      this.enemies=ENEMY_SEEDS.map(makeEnemy); this.projectiles=[]; this.effects=[];this.events=[];
      this.elapsed=0;this.kills=0;this.dead=false;this.bossStarted=false;this.hintCooldown=0;this.random=seeded(90210);
    }
    emit(type, detail={}) { this.events.push({type,...detail}); }
    get damage() { return 24+(this.player.level-1)*5+(this.player.sword?18:0); }
    get xpNeeded() { return 38+this.player.level*18; }
    get region() {
      const p=this.player;
      if (p.x>1790 && p.y<700) return '月痕遗迹';
      if (p.y>1080 && p.x<950) return '萤火村';
      if (p.y>735&&p.y<930) return '风语溪';
      if (p.y<735 && p.x<1050) return '暮萤林地';
      if (p.y<735) return '失落的旧路';
      return '苔影林地';
    }
    move(entity, dx, dy) {
      // Substeps prevent a dash or slow animation frame from crossing thin obstacles.
      const steps=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))/8));
      for(let i=0;i<steps;i++) {
        if(!solidAt(entity.x+dx/steps,entity.y,entity.r,this.quest)) entity.x+=dx/steps;
        if(!solidAt(entity.x,entity.y+dy/steps,entity.r,this.quest)) entity.y+=dy/steps;
      }
    }
    nearestEnemy(range) { return this.enemies.filter(e=>e.alive&&distance(e,this.player)<range&&(e.type!=='boss'||this.quest>=2)).sort((a,b)=>distance(a,this.player)-distance(b,this.player))[0]; }
    attack() {
      const p=this.player;if(this.dead||this.quest===4||p.attackCooldown>0)return false;
      const target=this.nearestEnemy(95); if(target)p.angle=Math.atan2(target.y-p.y,target.x-p.x);
      p.attackCooldown=.37;
      this.effects.push({type:'slash',x:p.x,y:p.y,angle:p.angle,life:.22,maxLife:.22});
      this.emit('sound',{name:'slash'});
      for(const e of this.enemies) {
        const d=distance(p,e), angle=Math.atan2(e.y-p.y,e.x-p.x), diff=Math.atan2(Math.sin(angle-p.angle),Math.cos(angle-p.angle));
        if(e.alive&&d<68+e.r&&Math.abs(diff)<1.3&&(e.type!=='boss'||this.quest>=2)) this.hitEnemy(e,this.damage,angle,15);
      }
      return true;
    }
    cast() {
      const p=this.player;if(this.dead||this.quest===4||p.spellCooldown>0)return false;
      if(p.mp<15){this.notice('魔力不足，稍等片刻便会恢复');return false;}
      const target=this.nearestEnemy(450);if(target)p.angle=Math.atan2(target.y-p.y,target.x-p.x);
      p.mp-=15;p.spellCooldown=.65;
      this.projectiles.push({x:p.x+Math.cos(p.angle)*20,y:p.y+Math.sin(p.angle)*20,vx:Math.cos(p.angle)*430,vy:Math.sin(p.angle)*430,r:6,life:1.25,hostile:false,damage:38+p.level*7});
      this.emit('sound',{name:'magic'});return true;
    }
    dash(dx=0,dy=0) {
      const p=this.player;if(this.dead||this.quest===4||p.dashCooldown>0)return false;
      const len=Math.hypot(dx,dy);p.dashX=len?dx/len:Math.cos(p.angle);p.dashY=len?dy/len:Math.sin(p.angle);
      p.dashTime=.2;p.invulnerable=.32;p.dashCooldown=1.5;this.emit('sound',{name:'dash'});return true;
    }
    potion() {
      const p=this.player;if(this.dead)return false;
      if(p.potions<=0){this.notice('药水用完了，村里的米娅可以补给');return false;}
      if(p.hp>=p.maxHp){this.notice('生命已满，先留着药水吧');return false;}
      p.potions--;const healed=Math.min(p.maxHp-p.hp,60);p.hp+=healed;
      this.emit('float',{x:p.x,y:p.y-28,text:'+'+healed,color:'#b9dca2'});this.emit('sound',{name:'potion'});this.emit('save');return true;
    }
    hitEnemy(e,damage,angle=0,knockback=0) {
      if(!e.alive)return;
      e.hp-=damage;e.flash=.15;
      if(e.type!=='boss'&&knockback)this.move(e,Math.cos(angle)*knockback,Math.sin(angle)*knockback);
      this.emit('float',{x:e.x,y:e.y-20,text:String(damage),color:'#f3e8cb'});
      this.emit('burst',{x:e.x,y:e.y,color:e.type==='slime'?'#a2cf95':'#d7c796',count:8});
      if(e.hp<=0) {
        e.hp=0;e.alive=false;this.killed.add(e.id);this.kills++;this.player.coins+=e.coins;this.addXP(e.xp);
        this.emit('sound',{name:'kill'});this.emit('float',{x:e.x,y:e.y-40,text:'+'+e.xp+' 经验  ◈'+e.coins,color:'#e9c779'});
        if(this.random()<.16){this.player.potions++;this.emit('toast',{text:'拾取了一瓶林间药水'});}
        if(e.type==='boss') {this.quest=3;this.projectiles=this.projectiles.filter(p=>!p.hostile);this.emit('toast',{text:'荒根沉睡了。前往灯塔，让微光重返森林。',gold:true});this.emit('quest');}
        this.emit('save');
      } else this.emit('sound',{name:'hit'});
    }
    addXP(amount) {
      const p=this.player;p.xp+=amount;
      while(p.xp>=this.xpNeeded) {
        p.xp-=this.xpNeeded;p.level++;p.maxHp=100+(p.level-1)*14;p.maxMp=60+(p.level-1)*6;p.hp=p.maxHp;p.mp=p.maxMp;
        this.emit('toast',{text:'等级提升 · Lv.'+p.level+'  生命、魔力与攻击力提升',gold:true});this.emit('sound',{name:'levelup'});
        this.emit('burst',{x:p.x,y:p.y,color:'#f2d38b',count:26});
      }
    }
    hurt(amount,source) {
      const p=this.player;if(p.invulnerable>0||this.dead)return;
      p.hp=Math.max(0,p.hp-amount);p.invulnerable=.8;
      this.emit('sound',{name:'hurt'});this.emit('shake',{amount:5});this.emit('float',{x:p.x,y:p.y-30,text:'−'+amount,color:'#e98273'});
      if(source) {const a=Math.atan2(p.y-source.y,p.x-source.x);this.move(p,Math.cos(a)*15,Math.sin(a)*15);}
      if(p.hp===0) {this.dead=true;this.emit('sound',{name:'lose'});this.emit('death');}
    }
    notice(text) {if(this.hintCooldown<=0){this.emit('toast',{text});this.hintCooldown=2;}}
    nearInteractable() {
      const items=[...NPCS,...CHESTS.filter(c=>!this.opened.has(c.id)).map(c=>({...c,type:'chest'})),BEACON];
      const close=items.filter(i=>distance(i,this.player)<75).sort((a,b)=>distance(a,this.player)-distance(b,this.player));
      return close[0]||null;
    }
    interact() {
      if(this.dead)return null;
      const item=this.nearInteractable();if(!item)return null;
      if(item.type==='chest') {
        if(this.enemies.some(e=>e.alive&&distance(e,item)<95)){this.notice('先击退宝箱附近的敌人');return null;}
        this.opened.add(item.id);this.player.coins+=item.stone?15:25;this.player.potions+=item.stone?1:2;
        if(item.stone){this.stones++;this.addXP(20);this.emit('toast',{text:'获得萤石 '+this.stones+'/3 · 药水 +1 · 金币 +15',gold:true});}
        else this.emit('toast',{text:'打开行囊 · 药水 +2 · 金币 +25',gold:true});
        this.emit('burst',{x:item.x,y:item.y,color:'#f2c86f',count:25});this.emit('sound',{name:'interact'});this.emit('quest');this.emit('save');
        return {type:'loot'};
      }
      if(item.id==='beacon') {
        if(this.quest===3) {this.quest=4;this.player.hp=this.player.maxHp;this.emit('sound',{name:'win'});this.emit('win');this.emit('save');return {type:'win'};}
        this.notice(this.quest===4?'灯火长明，欢迎随时回到森林。':'古老的树根仍缠绕着灯塔，先击败荒根守卫。');return null;
      }
      this.emit('sound',{name:'interact'});return item;
    }
    acceptQuest() {if(this.quest!==0)return false;this.quest=1;this.emit('quest');this.emit('save');return true;}
    turnIn() {
      if(this.quest!==1||this.stones<3)return false;
      this.quest=2;this.player.sword=true;this.player.potions+=2;this.player.hp=this.player.maxHp;this.player.mp=this.player.maxMp;this.addXP(45);
      this.emit('toast',{text:'获得月辉剑 · 攻击 +18 · 遗迹封印已解除',gold:true});this.emit('sound',{name:'levelup'});this.emit('quest');this.emit('save');return true;
    }
    buyPotion() {if(this.player.coins<12){this.notice('需要 12 枚金币');return false;}this.player.coins-=12;this.player.potions++;this.emit('sound',{name:'select'});this.emit('save');return true;}
    rest() {this.player.hp=this.player.maxHp;this.player.mp=this.player.maxMp;this.emit('sound',{name:'potion'});this.emit('save');}
    revive() {
      const p=this.player;p.x=610;p.y=1340;p.hp=p.maxHp;p.mp=p.maxMp;p.coins=Math.floor(p.coins*.9);p.invulnerable=2;p.dashTime=0;
      this.dead=false;this.bossStarted=false;this.projectiles=[];
      this.enemies=this.enemies.map(e=>e.alive?makeEnemy(ENEMY_SEEDS.find(s=>s[0]===e.id)):e);this.emit('save');
    }
    step(dt,input={}) {
      if(this.dead||this.quest===4)return;
      dt=clamp(dt,0,.05);this.elapsed+=dt;this.hintCooldown-=dt;const p=this.player;
      for(const key of ['attackCooldown','spellCooldown','dashCooldown','dashTime','invulnerable']) p[key]=Math.max(0,p[key]-dt);
      p.mp=Math.min(p.maxMp,p.mp+6*dt);
      if(distance(p,FIRE)<90&&!this.enemies.some(e=>e.alive&&distance(e,p)<220))p.hp=Math.min(p.maxHp,p.hp+12*dt);
      let dx=(input.right?1:0)-(input.left?1:0),dy=(input.down?1:0)-(input.up?1:0),len=Math.hypot(dx,dy);
      p.moving=len>0;
      if(p.dashTime>0){this.move(p,p.dashX*570*dt,p.dashY*570*dt);this.emit('trail',{x:p.x,y:p.y});}
      else if(len){dx/=len;dy/=len;p.angle=Math.atan2(dy,dx);this.move(p,dx*175*dt,dy*175*dt);p.walk+=dt*10;}
      if(input.attack)this.attack();if(input.magic)this.cast();
      for(const e of this.enemies) {
        if(!e.alive)continue;e.flash=Math.max(0,e.flash-dt);e.cooldown-=dt;
        if(e.type==='boss'&&this.quest<2)continue;
        const d=distance(e,p), aggro=e.type==='boss'?370:e.type==='wolf'?270:220;
        if(d>aggro&&e.windup<=0) {
          const home=distance(e,{x:e.homeX,y:e.homeY});if(home>8){const a=Math.atan2(e.homeY-e.y,e.homeX-e.x);this.move(e,Math.cos(a)*e.speed*.45*dt,Math.sin(a)*e.speed*.45*dt);}continue;
        }
        if(e.type==='boss'&&!this.bossStarted){this.bossStarted=true;this.emit('sound',{name:'boss'});this.emit('toast',{text:'荒根守卫苏醒了 · 留意地面的攻击预警',gold:true});}
        if(e.windup>0) {
          e.windup-=dt;
          if(e.windup<=0) {
            if(e.type==='boss') {
              if(e.phase%2===0) {
                this.effects.push({type:'impact',x:e.attackX,y:e.attackY,r:85,life:.5,maxLife:.5});
                if(distance(p,{x:e.attackX,y:e.attackY})<85+p.r)this.hurt(e.damage,e);
              } else for(let i=0;i<10;i++){const a=i*Math.PI/5+e.phase*.3;this.projectiles.push({x:e.x,y:e.y,vx:Math.cos(a)*145,vy:Math.sin(a)*145,r:7,life:2.8,hostile:true,damage:20});}
              e.phase++;
            } else {
              if(e.type==='wolf'){const a=Math.atan2(e.attackY-e.y,e.attackX-e.x);this.move(e,Math.cos(a)*40,Math.sin(a)*40);}
              if(distance(e,p)<e.r+p.r+25)this.hurt(e.damage,e);
              this.effects.push({type:'impact',x:e.x,y:e.y,r:e.r+14,life:.23,maxLife:.23});
            }
            e.cooldown=e.type==='boss'?1.8:e.type==='wolf'?1.4:1.25;
          }
        } else if(e.cooldown<=0&&d<(e.type==='boss'?300:e.type==='wolf'?77:49)) {
          e.windup=e.type==='boss'?1.05:e.type==='wolf'?.5:.65;e.attackX=p.x;e.attackY=p.y;
        } else if(d>(e.type==='boss'?130:e.r+p.r+5)) {
          const a=Math.atan2(p.y-e.y,p.x-e.x);this.move(e,Math.cos(a)*e.speed*dt,Math.sin(a)*e.speed*dt);
        }
        if(this.dead)break;
      }
      for(const b of this.projectiles) {
        b.life-=dt;b.x+=b.vx*dt;b.y+=b.vy*dt;
        if(b.x<0||b.y<0||b.x>W||b.y>H)b.life=0;
        if(b.hostile) {if(distance(b,p)<b.r+p.r){this.hurt(b.damage,b);b.life=0;}}
        else {const e=this.enemies.find(e=>e.alive&&distance(e,b)<e.r+b.r&&(e.type!=='boss'||this.quest>=2));if(e){this.hitEnemy(e,b.damage,Math.atan2(b.vy,b.vx),7);b.life=0;}}
      }
      this.projectiles=this.projectiles.filter(b=>b.life>0);for(const fx of this.effects)fx.life-=dt;this.effects=this.effects.filter(f=>f.life>0);
    }
    serialize() {
      const p=this.player;return {version:SAVE_VERSION,quest:this.quest,opened:[...this.opened],killed:[...this.killed],elapsed:Math.round(this.elapsed),kills:this.kills,
        player:{x:p.x,y:p.y,hp:p.hp,mp:p.mp,level:p.level,xp:p.xp,coins:p.coins,potions:p.potions}};
    }
    static fromSave(data) {
      if(!data||data.version!==SAVE_VERSION||!data.player||!Array.isArray(data.opened)||!Array.isArray(data.killed))return null;
      const g=new Game(),p=data.player;
      for(const k of ['x','y','hp','mp','level','xp','coins','potions'])if(typeof p[k]!=='number'||!Number.isFinite(p[k]))return null;
      if(!Number.isInteger(data.quest)||data.quest<0||data.quest>4)return null;
      g.opened=new Set(data.opened.filter(id=>CHESTS.some(c=>c.id===id)));
      g.stones=CHESTS.filter(c=>c.stone&&g.opened.has(c.id)).length;
      g.quest=data.quest;
      if(g.quest>=2&&g.stones<3)return null;
      g.killed=new Set(data.killed.filter(id=>ENEMY_SEEDS.some(e=>e[0]===id)));
      if(g.quest>=3&&!g.killed.has('boss'))return null;
      if(g.quest<3&&g.killed.has('boss'))return null;
      g.enemies.forEach(e=>{if(g.killed.has(e.id)){e.alive=false;e.hp=0;}});
      g.kills=g.killed.size;g.elapsed=typeof data.elapsed==='number'&&Number.isFinite(data.elapsed)?clamp(data.elapsed,0,1e7):0;
      const t=g.player;t.level=clamp(Math.floor(p.level),1,30);t.maxHp=100+(t.level-1)*14;t.maxMp=60+(t.level-1)*6;
      t.hp=clamp(p.hp,1,t.maxHp);t.mp=clamp(p.mp,0,t.maxMp);t.xp=clamp(p.xp,0,g.xpNeeded-1);
      t.coins=clamp(Math.floor(p.coins),0,99999);t.potions=clamp(Math.floor(p.potions),0,999);t.sword=g.quest>=2;
      t.x=clamp(p.x,60,W-60);t.y=clamp(p.y,70,H-60);
      if(solidAt(t.x,t.y,t.r,g.quest)){t.x=610;t.y=1340;}
      t.invulnerable=1.5;return g;
    }
  }
  const API={Game,W,H,NPCS,CHESTS,BEACON,FIRE,HOUSE_RECTS,SCENERY,ENEMY_SEEDS,clamp,distance,seeded,nearPath,inWater,solidAt};
  if(typeof module!=='undefined'&&module.exports)module.exports=API;else root.MosslightCore=API;
})(typeof globalThis!=='undefined'?globalThis:this);
