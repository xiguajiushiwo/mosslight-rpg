(function(){
  'use strict';
  const C=window.MosslightCore,$=id=>document.getElementById(id),canvas=$('world'),ctx=canvas.getContext('2d');
  const audio=new window.ForestAudio(),SAVE_KEY='mosslight-save-v1';
  let game=new C.Game(),screen='title',returnScreen='play',width=innerWidth,height=innerHeight,scale=1,dpr=1;
  let camera={x:630,y:1210},time=0,last=performance.now(),shake=0,saveTimer=0,hudTimer=0,toastTimers=[];
  const keys={},particles=[],floats=[],reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  let storageAvailable=true;
  function readSave(){try{const raw=localStorage.getItem(SAVE_KEY);return raw?C.Game.fromSave(JSON.parse(raw)):null;}catch{return null;}}
  function save(){if(game.dead)return;try{localStorage.setItem(SAVE_KEY,JSON.stringify(game.serialize()));$('save-status').textContent='旅途已记录';}catch{storageAvailable=false;$('save-status').textContent='此浏览器无法保存';}}
  function resize(){width=innerWidth;height=innerHeight;dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);scale=width<700?.82:width>1600?1.18:1;}
  addEventListener('resize',resize);resize();
  const terrain=document.createElement('canvas');terrain.width=C.W;terrain.height=C.H;const bg=terrain.getContext('2d');
  const rng=C.seeded(142857);
  function ellipse(c,x,y,rx,ry,color){c.fillStyle=color;c.beginPath();c.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),0,0,Math.PI*2);c.fill();}
  function polygon(c,points,color){c.fillStyle=color;c.beginPath();points.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath();c.fill();}
  function line(c,points,color,w=1){c.strokeStyle=color;c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.beginPath();points.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.stroke();}
  function glow(x,y,r,color){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);}
  function makeTerrain(){
    bg.fillStyle='#294a36';bg.fillRect(0,0,C.W,C.H);
    for(let i=0;i<780;i++){const x=rng()*C.W,y=rng()*C.H;ellipse(bg,x,y,20+rng()*110,12+rng()*60,['#31543a','#2d5038','#244530','#36543b','#203f30'][i%5]);}
    // Quiet clearings leave room for action and make destinations legible.
    ellipse(bg,605,1310,343,234,'#465a3b');ellipse(bg,430,490,145,120,'#3e5738');ellipse(bg,1540,1160,153,124,'#3b573a');
    const paths=[[[310,1330],[740,1330],[1135,1305],[1135,1120],[1135,880],[1135,775],[1135,485]],[[1135,1050],[1360,1060],[1530,1135]],[[430,485],[800,485],[1135,485],[1410,485],[1670,485],[2005,600],[2005,320]],[[1410,485],[1410,350]],[[550,1245],[610,1330]],[[800,1300],[790,1240]]];
    for(const p of paths){line(bg,p,'#223e2d',84);line(bg,p,'#64694a',73);line(bg,p,'#727252',57);}
    for(let i=0;i<21000;i++){
      const x=rng()*C.W,y=rng()*C.H;if(C.inWater(x,y))continue;
      const path=C.nearPath(x,y,-15);bg.fillStyle=path?['#a19b6d50','#4d5e3d60','#a2a07155'][i%3]:['#7a925b45','#142f2766','#9cae5b30','#4d70494d'][i%4];
      bg.fillRect(x,y,1+rng()*4,1+rng()*3);if(!path&&i%5===0)bg.fillRect(x+2,y-3,1,4);
    }
    // Stone paving in the ancient sanctuary.
    bg.fillStyle='#3c5142';bg.fillRect(1810,130,400,520);
    for(let y=145;y<650;y+=40)for(let x=1820;x<2200;x+=48){bg.fillStyle=(x+y)%3?'#536154':'#4b5d4d';bg.fillRect(x+(y%80?10:0),y,42,34);bg.fillStyle='#6f7b5d55';bg.fillRect(x+3,y+3,34,2);}
    ellipse(bg,2005,425,151,133,'#344e3c');bg.strokeStyle='#8ca07a66';bg.lineWidth=3;bg.beginPath();bg.ellipse(2005,425,145,128,0,0,Math.PI*2);bg.stroke();
    bg.beginPath();bg.ellipse(2005,425,117,102,0,0,Math.PI*2);bg.strokeStyle='#728a6466';bg.lineWidth=1;bg.stroke();
    bg.fillStyle='#183e3c';bg.fillRect(0,762,C.W,132);bg.fillStyle='#286360';bg.fillRect(0,775,C.W,105);
    for(let i=0;i<550;i++){const x=rng()*C.W,y=780+rng()*94;bg.fillStyle=['#43827855','#6ca48b33','#153f3e55'][i%3];bg.fillRect(x,y,8+rng()*33,2);}
    for(let x=0;x<C.W;x+=13){const h=3+rng()*9;bg.fillStyle='#748767';bg.fillRect(x,770-h,9,h);bg.fillStyle='#456343';bg.fillRect(x,880,10,h+4);}
    // Wooden bridge; collision follows its usable deck exactly.
    bg.fillStyle='#193b32';bg.fillRect(1053,758,164,141);bg.fillStyle='#655a3f';bg.fillRect(1063,752,144,148);
    for(let y=758;y<896;y+=12){bg.fillStyle=y%24?'#a08c5c':'#958356';bg.fillRect(1069,y,132,9);bg.fillStyle='#c1a77b55';bg.fillRect(1074,y+1,120,2);}
    for(const x of [1058,1203]){bg.fillStyle='#5b513a';bg.fillRect(x,745,7,160);for(let y=749;y<910;y+=38){bg.fillStyle='#c1ac7b';bg.fillRect(x-3,y,12,10);}}
    // Small crescent ruin pieces near the northern chest.
    for(const [x,y] of [[1345,300],[1480,300],[1355,410],[1480,410],[1840,180],[2170,180],[1840,600],[2170,600]]){bg.fillStyle='#1c362b';bg.fillRect(x-13,y-8,31,22);bg.fillStyle='#6c7c66';bg.fillRect(x-12,y-25,25,35);bg.fillStyle='#93a080';bg.fillRect(x-14,y-29,29,8);bg.fillStyle='#365640';bg.fillRect(x-11,y-5,14,13);}
    for(const f of C.SCENERY.flowers){if(C.inWater(f.x,f.y)||C.nearPath(f.x,f.y,-8))continue;if(f.color<2){bg.fillStyle=f.color?'#c1bb8177':'#b9cf9877';bg.fillRect(f.x,f.y,2,2);bg.fillStyle='#6a8954';bg.fillRect(f.x,f.y+2,1,4);}}
    // Camp clearing and worn stepping stones.
    ellipse(bg,C.FIRE.x,C.FIRE.y,48,32,'#5c6241');for(let i=0;i<9;i++){const a=i*Math.PI*2/9;ellipse(bg,C.FIRE.x+Math.cos(a)*28,C.FIRE.y+Math.sin(a)*18,7,5,'#929273');}
  }
  makeTerrain();
  const sprites={};
  function sprite(name,w,h,paint){const s=document.createElement('canvas');s.width=w;s.height=h;paint(s.getContext('2d'));sprites[name]=s;}
  function r(c,x,y,w,h,color){c.fillStyle=color;c.fillRect(x,y,w,h);}
  for(let variant=0;variant<4;variant++)sprite('tree'+variant,66,82,c=>{
    r(c,29,48,10,33,'#293b29');r(c,32,49,5,29,'#586145');r(c,34,53,2,24,'#777b52');r(c,24,76,20,4,'#283e2c');
    const tones=[['#183f31','#255039','#386341','#4b754a','#668252'],['#193b2e','#264a34','#365c3c','#4d7144','#6b8250'],['#173c30','#244d39','#356347','#4c7751','#6a8a5e'],['#17382b','#284a32','#3c603c','#557448','#748c54']][variant];
    polygon(c,[[12,61],[4,48],[9,34],[15,29],[12,18],[24,6],[38,4],[51,12],[55,27],[63,38],[59,54],[49,63]],tones[0]);
    ellipse(c,27,29,22,23,tones[1]);ellipse(c,43,35,18,23,tones[1]);ellipse(c,22,41,19,18,tones[2]);ellipse(c,40,25,18,18,tones[2]);ellipse(c,28,20,17,16,tones[3]);ellipse(c,17,34,12,10,tones[3]);ellipse(c,42,23,12,10,tones[3]);
    r(c,22,7,10,2,tones[4]);r(c,14,16,8,2,tones[4]);r(c,36,14,9,2,tones[4]);r(c,10,31,7,2,tones[4]);r(c,29,36,10,2,tones[4]);r(c,43,30,7,2,tones[4]);r(c,39,47,10,3,tones[0]);r(c,17,49,8,3,tones[0]);
  });
  function drawTree(o){const s=sprites['tree'+o.variant],f=o.size*1.65;const obscures=screen!=='title'&&Math.abs(game.player.x-o.x)<40*f&&game.player.y<o.y&&game.player.y>o.y-100*f;ctx.globalAlpha=obscures?.36:1;ctx.drawImage(s,o.x-33*f,o.y-77*f,66*f,82*f);ctx.globalAlpha=1;}
  sprite('house',92,100,c=>{
    r(c,14,42,66,49,'#263a2b');r(c,16,43,62,45,'#9a9369');r(c,19,48,56,37,'#b1a478');r(c,18,59,58,3,'#7d7956');r(c,18,76,58,3,'#7d7956');r(c,21,45,4,42,'#57543b');r(c,69,45,4,42,'#57543b');
    r(c,41,64,17,25,'#344331');r(c,44,66,11,21,'#655d40');r(c,52,77,2,2,'#e1c477');
    r(c,27,55,12,15,'#665b3c');r(c,29,57,8,11,'#e4c17a');r(c,32,57,2,11,'#8d8050');r(c,60,55,10,15,'#665b3c');r(c,62,57,6,11,'#e4c17a');
    polygon(c,[[5,49],[13,29],[36,5],[51,6],[87,40],[89,49]],'#293b2e');polygon(c,[[7,43],[36,8],[51,9],[85,42],[83,45],[8,46]],'#496344');
    for(let y=17;y<44;y+=7){const inset=(44-y)*.85;line(c,[[10+inset,y],[82-inset*.6,y]],y%2?'#637a4d':'#728654',3);}
    r(c,60,4,10,22,'#69745b');r(c,58,2,14,5,'#9a9d74');r(c,61,7,3,13,'#8d9270');r(c,40,88,20,5,'#a8a27b');r(c,13,86,16,6,'#34583a');r(c,66,84,16,7,'#3f6540');
  });
  function drawHouse(o,i){const f=1.55;ctx.drawImage(sprites.house,o.x-12,o.y-67,92*f,100*f);glow(o.x+46,o.y+30,39,'#e8c87b19');if(i<2){const t=time*.35+i;for(let j=0;j<3;j++)ellipse(ctx,o.x+91+Math.sin(t+j)*6,o.y-65-j*15-((time*8)%15),10+j*3,5+j*2,'#b3bea12b');}}
  function drawPerson(x,y,kind='hero',angle=0,walk=0,moving=false){
    const hero=kind==='hero',p=game.player;let bob=moving?Math.sin(walk*2)*1.3:Math.sin(time*2)*.5;
    ctx.save();ctx.translate(Math.round(x),Math.round(y+bob));
    if(hero&&p.invulnerable>0&&Math.floor(time*5)%2===0)ctx.globalAlpha=.55;
    ellipse(ctx,0,1,13,5,'#102a2777');
    const stride=moving?Math.sin(walk)*4:0;
    r(ctx,-7,-5+stride,6,7,'#26382a');r(ctx,2,-5-stride,6,7,'#26382a');
    polygon(ctx,[[-11,-23],[10,-23],[14,-7],[4,-3],[-13,-7]],hero?'#6d8d64':kind==='keeper'?'#617963':'#8e7963');
    r(ctx,-8,-22,17,14,hero?'#9db080':'#7f9870');r(ctx,-9,-13,19,3,'#5b6b47');r(ctx,-2,-12,5,3,'#c6ad68');
    polygon(ctx,[[-12,-23],[-11,-35],[-5,-41],[6,-40],[12,-33],[12,-23],[5,-19],[-6,-19]],hero?'#e7dfb9':kind==='keeper'?'#9cb18a':'#bead89');
    r(ctx,-9,-33,18,10,hero?'#c8c89a':'#71886b');r(ctx,-7,-31,15,10,'#3a4c37');r(ctx,-4,-29,12,8,'#bba880');
    const look=angle>Math.PI/2||angle<-Math.PI/2?-1:1;r(ctx,look<0?-5:4,-28,2,2,'#263d30');
    r(ctx,-13,-32,4,11,hero?'#e9e1bb':'#a7b78e');r(ctx,-10,-38,17,4,hero?'#f3e8cb':'#b8c49c');r(ctx,9,-31,4,10,hero?'#d5d3a7':'#9baa83');
    if(hero){
      r(ctx,12,-19,3,13,p.sword?'#a6daca':'#a9b8a2');r(ctx,10,-9,7,3,'#c3a76a');r(ctx,13,-6,2,5,'#715e3c');
      r(ctx,-17,-18,4,10,'#977f48');r(ctx,-19,-17,8,8,'#d1a661');r(ctx,-17,-16,4,6,'#f4d891');glow(-15,-14,28,'#e7c77518');
      if(p.sword)glow(13,-14,23,'#9ce3c130');
    }else if(kind==='keeper'){r(ctx,15,-39,3,41,'#a19a6b');r(ctx,13,-42,8,3,'#bcb182');r(ctx,19,-40,2,11,'#9c945d');r(ctx,17,-31,7,9,'#d7b568');glow(21,-26,38,'#eac67b23');}
    else{r(ctx,12,-20,9,15,'#8c7353');r(ctx,14,-24,5,6,'#b7aa73');r(ctx,14,-18,4,10,'#c2a277');}
    ctx.restore();
  }
  function drawChest(chest){
    const opened=game.opened.has(chest.id),x=chest.x,y=chest.y;ellipse(ctx,x,y+3,19,7,'#142f2377');
    r(ctx,x-16,y-18,32,20,'#493e29');r(ctx,x-14,y-16,28,17,'#9e7d42');r(ctx,x-14,y-8,28,3,'#5b5031');
    r(ctx,x-11,y-16,3,17,'#d0b467');r(ctx,x+8,y-16,3,17,'#d0b467');r(ctx,x-3,y-10,6,7,'#e8cb7d');
    if(opened){r(ctx,x-15,y-26,30,10,'#765d36');r(ctx,x-12,y-22,24,6,'#302f20');}
    else{r(ctx,x-16,y-20,32,5,'#c5a05c');glow(x,y-13,48,chest.stone?'#b9dc9c20':'#edc77715');
      if(chest.stone){const bob=Math.sin(time*2+chest.x)*3;polygon(ctx,[[x,y-52+bob],[x+6,y-43+bob],[x,y-34+bob],[x-6,y-43+bob]],'#c9e5b4');glow(x,y-43,22,'#cfedb839');}}
  }
  function drawEnemy(e){
    const x=e.x,y=e.y,t=time*3+e.seed,bob=Math.sin(t)*2;
    ctx.save();ctx.translate(Math.round(x),Math.round(y));ellipse(ctx,0,2,e.r+3,e.r*.35,'#0e291f77');
    if(e.type==='slime'){
      const squash=e.windup>0?3:Math.sin(t)*1.4;polygon(ctx,[[-19,-3],[-18,-14+squash],[-12,-24+squash],[0,-28+squash],[12,-24+squash],[18,-15+squash],[20,-3],[11,2],[-10,2]],e.flash>0?'#e9ead0':'#789f67');
      ellipse(ctx,-3,-17+squash,12,9,e.flash>0?'#fff1cf':'#a2bd7e');r(ctx,-10,-15+squash,3,4,'#263d2e');r(ctx,5,-15+squash,3,4,'#263d2e');r(ctx,-4,-7+squash,6,2,'#4a7048');r(ctx,-5,-25+squash,7,2,'#d1db99');
    }else if(e.type==='wolf'){
      const face=game.player.x<e.x?-1:1;ctx.scale(face,1);const col=e.flash>0?'#f4e6c5':'#9ba28c';
      polygon(ctx,[[-24,-20],[-32,-27],[-28,-14],[-16,-8],[-10,1],[-5,0],[-5,-6],[11,-7],[14,1],[20,0],[21,-13],[28,-20],[20,-28],[18,-35],[12,-28],[4,-25]],col);
      polygon(ctx,[[-13,-22],[-3,-26],[12,-23],[15,-14],[-11,-11]],e.flash>0?'#fff1d2':'#c2c3a2');r(ctx,18,-24,3,3,'#d5bb68');r(ctx,25,-21,4,3,'#24382b');r(ctx,-8,-4,4,7,'#5f6d55');r(ctx,16,-5,4,7,'#5f6d55');
    }else{
      const col=e.flash>0?'#dfdfb5':'#718363';
      polygon(ctx,[[-40,0],[-23,-14],[-28,-54],[-45,-78],[-55,-83],[-48,-94],[-28,-81],[-20,-99],[-9,-95],[-8,-71],[10,-72],[18,-104],[30,-108],[29,-84],[49,-98],[55,-92],[34,-65],[29,-24],[47,-1],[25,3],[12,-10],[-9,-8],[-24,4]],'#344f38');
      polygon(ctx,[[-26,-5],[-16,-28],[-21,-65],[-13,-88],[-4,-66],[10,-64],[21,-86],[23,-50],[17,-25],[28,-4],[9,-10],[-7,-8]],col);
      r(ctx,-15,-48,11,4,'#e6d184');r(ctx,7,-48,11,4,'#e6d184');r(ctx,-4,-34,9,5,'#2c4531');
      ellipse(ctx,-26,-72,22,13,'#3f6740');ellipse(ctx,16,-88,25,13,'#507847');ellipse(ctx,36,-66,16,11,'#3a603c');r(ctx,-17,-17,5,8,'#98a16d');r(ctx,9,-58,4,13,'#9caa79');
      glow(0,-45,55,'#deca7d13');
    }
    if(e.hp<e.maxHp&&e.type!=='boss'){r(ctx,-18,-(e.type==='wolf'?43:35),36,3,'#172c21');r(ctx,-18,-(e.type==='wolf'?43:35),36*e.hp/e.maxHp,3,'#d6b078');}
    ctx.restore();
  }
  function drawBeacon(){
    const {x,y}=C.BEACON,lit=game.quest===4;ellipse(ctx,x,y+10,39,13,'#1c362c');
    r(ctx,x-31,y-4,62,14,'#6f7e66');r(ctx,x-26,y-10,52,9,'#98a183');r(ctx,x-15,y-79,30,68,'#5d7563');r(ctx,x-12,y-76,8,63,'#8a9a7c');r(ctx,x+7,y-70,5,56,'#425e4b');r(ctx,x-22,y-84,44,9,'#9aab8a');
    polygon(ctx,[[x-22,y-85],[x-15,y-115],[x,y-126],[x+17,y-115],[x+23,y-85]],'#395848');
    r(ctx,x-13,y-112,26,25,lit?'#e1c57d':'#718d72');r(ctx,x-3,y-115,6,31,'#c5d3a2');r(ctx,x-16,y-103,32,4,'#a7bb91');
    if(lit){glow(x,y-100,150,'#efd49055');glow(x,y-100,40,'#fff5be99');}else if(game.quest===3){glow(x,y-100,70,'#bddeab44');}
    if(game.quest<2){ctx.strokeStyle='#b9d3a077';ctx.lineWidth=2;ctx.setLineDash([8,10]);ctx.strokeRect(1810,130,400,520);ctx.setLineDash([]);glow(2005,650,70,'#a5d0a322');label('萤石封印 · 完成洛恩的委托',2005,674,'#c5d8b0',10);}
  }
  function label(text,x,y,color='#d7dfbf',size=10){ctx.font=`${size}px "Microsoft YaHei", sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineWidth=3;ctx.strokeStyle='#133126bb';ctx.strokeText(text,x,y);ctx.fillStyle=color;ctx.fillText(text,x,y);}
  function visible(x,y,margin=160){return Math.abs(x-camera.x)<width/scale/2+margin&&Math.abs(y-camera.y)<height/scale/2+margin;}
  function drawWorld(){
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width,height);ctx.fillStyle='#18372c';ctx.fillRect(0,0,width,height);
    const s=screen==='title'?Math.max(.85,Math.min(1.15,width/1250)):scale;
    const sx=!reduced&&shake>0?(Math.random()-.5)*shake:0,sy=!reduced&&shake>0?(Math.random()-.5)*shake:0;
    ctx.save();ctx.translate(width/2+sx,height/2+sy);ctx.scale(s,s);ctx.translate(-camera.x,-camera.y);ctx.imageSmoothingEnabled=false;
    ctx.drawImage(terrain,0,0);
    for(let i=0;i<45;i++){const x=(i*83+time*13)%C.W,y=788+(i*29)%80;if(x>1050&&x<1220)continue;ctx.fillStyle='#a2c6a627';ctx.fillRect(x,y,10+Math.sin(time+i)*5,1);}
    for(const o of C.SCENERY.trees)if(visible(o.x,o.y))ellipse(ctx,o.x+13,o.y+1,36*o.size,12*o.size,'#102a2766');
    for(const o of C.SCENERY.rocks)if(visible(o.x,o.y)){polygon(ctx,[[o.x-o.size,o.y],[o.x-o.size*.8,o.y-o.size*.7],[o.x,o.y-o.size],[o.x+o.size*.8,o.y-o.size*.5],[o.x+o.size,o.y]],'#6e7e60');line(ctx,[[o.x-o.size*.7,o.y-o.size*.6],[o.x,o.y-o.size*.85],[o.x+o.size*.5,o.y-o.size*.55]],'#9aa180',2);}
    if(screen!=='title')for(const e of game.enemies){if(!e.alive||e.windup<=0)continue;const full=e.type==='boss'?1.05:e.type==='wolf'?.5:.65,progress=1-e.windup/full;
      if(e.type==='boss'){
        const x=e.phase%2===0?e.attackX:e.x,y=e.phase%2===0?e.attackY:e.y,radius=e.phase%2===0?85:65;
        ellipse(ctx,x,y,radius,radius,'#e982731e');ctx.strokeStyle='#f0a08b';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,radius,0,Math.PI*2);ctx.stroke();ellipse(ctx,x,y,radius*progress,radius*progress,'#e9827338');
      }else{ellipse(ctx,e.x,e.y,e.r+18,e.r+18,'#e9827327');ctx.strokeStyle='#e6a17a';ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+18,-Math.PI/2,-Math.PI/2+Math.PI*2*progress);ctx.stroke();}}
    const drawables=[];
    for(const t of C.SCENERY.trees)if(visible(t.x,t.y))drawables.push({y:t.y,draw:()=>drawTree(t)});
    C.HOUSE_RECTS.forEach((o,i)=>{if(visible(o.x,o.y))drawables.push({y:o.y+o.h,draw:()=>drawHouse(o,i)});});
    for(const c of C.CHESTS)if(visible(c.x,c.y))drawables.push({y:c.y,draw:()=>drawChest(c)});
    for(const n of C.NPCS)drawables.push({y:n.y,draw:()=>drawPerson(n.x,n.y,n.type,Math.PI/2)});
    drawables.push({y:C.BEACON.y,draw:drawBeacon});
    if(screen!=='title')for(const e of game.enemies)if(e.alive&&visible(e.x,e.y))drawables.push({y:e.y,draw:()=>drawEnemy(e)});
    const p=game.player;drawables.push({y:p.y,draw:()=>drawPerson(p.x,p.y,'hero',p.angle,p.walk,p.moving&&screen==='play')});
    drawables.push({y:C.FIRE.y,draw:()=>{const {x,y}=C.FIRE;r(ctx,x-13,y-6,26,6,'#534531');line(ctx,[[x-10,y+1],[x+10,y-9]],'#8d7345',5);glow(x,y-14,80,'#f2b76628');polygon(ctx,[[x-13,y-6],[x-6,y-21],[x-3,y-14],[x+3,y-34-Math.sin(time*9)*4],[x+10,y-20],[x+14,y-6]],'#d69a4d');polygon(ctx,[[x-6,y-5],[x-4,y-17],[x+2,y-12],[x+5,y-25],[x+8,y-6]],'#efd78d');}});
    drawables.sort((a,b)=>a.y-b.y).forEach(o=>o.draw());
    if(screen!=='title'){
      for(const n of C.NPCS){label(n.type==='keeper'?'洛恩 · 守灯人':'米娅 · 草药师',n.x,n.y-64,'#d8dfb5',9);const q=n.type==='keeper'&&(game.quest===0||(game.quest===1&&game.stones===3));label(q?'!':'⋯',n.x,n.y-83+Math.sin(time*2)*3,q?'#f2ca78':'#bace9e',q?20:18);}
      for(const b of game.projectiles){glow(b.x,b.y,20,b.hostile?'#e49a7c45':'#b6e4bd55');ellipse(ctx,b.x,b.y,b.r,b.r,b.hostile?'#e4a486':'#d5f1bf');line(ctx,[[b.x,b.y],[b.x-b.vx*.025,b.y-b.vy*.025]],b.hostile?'#b86f5b':'#9ed7b4',3);}
      for(const fx of game.effects){const progress=1-fx.life/fx.maxLife;ctx.globalAlpha=1-progress;if(fx.type==='slash'){ctx.strokeStyle=game.player.sword?'#d5f3cd':'#efe3b4';ctx.lineWidth=8*(1-progress)+2;ctx.beginPath();ctx.arc(fx.x,fx.y,48+progress*16,fx.angle-1.15+progress*.5,fx.angle+1.1+progress*.5);ctx.stroke();}else{ctx.strokeStyle='#d8b58d';ctx.lineWidth=3;ctx.beginPath();ctx.arc(fx.x,fx.y,fx.r*progress,0,Math.PI*2);ctx.stroke();}ctx.globalAlpha=1;}
    }
    for(const particle of particles){ctx.globalAlpha=Math.min(1,particle.life/particle.maxLife);ctx.fillStyle=particle.color;ctx.fillRect(particle.x,particle.y,particle.size,particle.size);}ctx.globalAlpha=1;
    for(const f of floats){ctx.globalAlpha=Math.min(1,f.life*2);label(f.text,f.x,f.y,f.color,f.text.length>6?10:13);}ctx.globalAlpha=1;
    // Fireflies live in world space, so they drift naturally as the camera moves.
    for(let i=0;i<55;i++){const x=(i*233+Math.sin(time*.4+i)*25)%C.W,y=(i*157+Math.cos(time*.3+i)*18)%C.H;if(!visible(x,y,20))continue;const a=(Math.sin(time*1.3+i)+1)*.25+.1;ctx.globalAlpha=a;ellipse(ctx,x,y,1.8,1.8,'#e9eab0');glow(x,y,13,'#d4e4a137');}ctx.globalAlpha=1;
    const shade=ctx.createLinearGradient(0,0,C.W,C.H);shade.addColorStop(0,'#153c3420');shade.addColorStop(1,'#082d2b28');ctx.fillStyle=shade;ctx.fillRect(0,0,C.W,C.H);
    ctx.restore();
  }
  function toast(text,gold=false){const el=document.createElement('div');el.className='toast'+(gold?' gold':'');el.textContent=text;$('toasts').append(el);while($('toasts').children.length>3)$('toasts').firstChild.remove();const timer=setTimeout(()=>el.remove(),4000);toastTimers.push(timer);}
  function consumeEvents(){
    const events=game.events.splice(0);
    for(const event of events){
      if(event.type==='sound')audio.play(event.name);
      else if(event.type==='toast')toast(event.text,event.gold);
      else if(event.type==='save')save();
      else if(event.type==='quest')updateHUD();
      else if(event.type==='float')floats.push({...event,life:1.2});
      else if(event.type==='shake')shake=reduced?0:event.amount;
      else if(event.type==='burst'){for(let i=0;i<(reduced?5:event.count);i++){const a=Math.random()*Math.PI*2,s=25+Math.random()*85;particles.push({x:event.x,y:event.y-12,vx:Math.cos(a)*s,vy:Math.sin(a)*s-25,life:.4+Math.random()*.45,maxLife:.85,size:2+Math.random()*3,color:event.color});}}
      else if(event.type==='trail'&&!reduced)particles.push({x:event.x-5,y:event.y-13,vx:0,vy:0,life:.2,maxLife:.2,size:10,color:'#a2cf9b'});
      else if(event.type==='death')showDeath();
      else if(event.type==='win')showEnding();
    }
  }
  const QUESTS=[
    ['一盏未亮的灯','与村中的守灯人洛恩交谈','靠近 NPC 后按 E'],
    ['寻找散落的萤石','探索西林、河畔与旧塔的宝箱',''],
    ['古林深处的回声','前往东北的月痕遗迹，击败荒根守卫','月辉剑已装备 · M 查看地图'],
    ['让微光重返森林','前往遗迹北端，点亮古林灯塔','靠近灯塔后按 E'],
    ['灯火长明','你让森林重新记起了温暖','冒险完成']
  ];
  function updateHUD(){
    const p=game.player;$('level-badge').textContent=p.level;$('level-label').textContent='LV. '+p.level;
    $('hp-bar').style.width=(p.hp/p.maxHp*100)+'%';$('hp-label').textContent=Math.ceil(p.hp)+' / '+p.maxHp;
    $('mp-bar').style.width=(p.mp/p.maxMp*100)+'%';$('mp-label').textContent=Math.floor(p.mp)+' / '+p.maxMp;
    $('xp-bar').style.width=(p.xp/game.xpNeeded*100)+'%';$('coin-count').textContent=p.coins;$('potion-count').textContent=p.potions;
    $('region-name').textContent=game.region;$('magic-cooldown').style.height=(p.spellCooldown/.65*100)+'%';$('dash-cooldown').style.height=(p.dashCooldown/1.5*100)+'%';
    const q=QUESTS[game.quest];$('quest-title').textContent=q[0];$('quest-detail').textContent=game.quest===1&&game.stones===3?'萤石已集齐，回村交给洛恩':q[1];
    $('quest-progress').textContent=game.quest===1?'萤石 '+game.stones+' / 3  ·  M 查看地图':q[2];
    const near=game.nearInteractable();$('interact-hint').hidden=screen!=='play'||!near;
    if(near)$('interact-hint').querySelector('span').textContent=near.type==='chest'?'打开 '+near.name:near.id==='beacon'?'点亮灯塔':'与'+near.name.split(' · ')[1]+'交谈';
    const boss=game.enemies.find(e=>e.type==='boss');$('boss-hud').hidden=!boss.alive||!game.bossStarted||C.distance(game.player,boss)>470;
    $('boss-bar').style.width=(boss.hp/boss.maxHp*100)+'%';
  }
  function clearKeys(){for(const key in keys)delete keys[key];}
  function startGame(saved=false){
    audio.start();game=saved?readSave()||new C.Game():new C.Game();screen='play';clearKeys();particles.length=0;floats.length=0;
    camera.x=game.player.x;camera.y=game.player.y;$('title-screen').hidden=true;$('hud').hidden=false;$('modal-shade').hidden=true;$('dialogue').hidden=true;
    $('toasts').replaceChildren();toastTimers.forEach(clearTimeout);toastTimers=[];updateHUD();save();
    if(game.quest===4){showEnding();return;}
    toast(saved?'欢迎回来，守灯学徒。':'WASD 移动 · E 与洛恩交谈 · J 挥剑 · K 萤火术',true);canvas.focus();
  }
  function returnTitle(){save();screen='title';clearKeys();$('title-screen').hidden=false;$('hud').hidden=true;$('modal-shade').hidden=true;$('dialogue').hidden=true;updateContinue();audio.resume();}
  function updateContinue(){const saved=readSave();$('continue-btn').hidden=!saved;$('start-btn').firstChild.textContent=saved?'开启新旅程 ':'踏入森林 ';}
  function makeButton(text,handler,className='primary'){const b=document.createElement('button');b.textContent=text;b.className=className;b.onclick=()=>{audio.play('select');handler();};return b;}
  function modal(title,html,kicker='THE FIREFLY WOODS',canClose=true){
    if(screen!=='modal')returnScreen=screen;screen='modal';clearKeys();$('dialogue').hidden=true;$('modal-title').textContent=title;$('modal-kicker').textContent=kicker;$('modal-content').innerHTML=html;$('modal-close').hidden=!canClose;$('modal-shade').hidden=false;
    requestAnimationFrame(()=>{$('modal').querySelector('button:not([hidden])')?.focus();});
  }
  function closeModal(){if($('modal-close').hidden)return;$('modal-shade').hidden=true;screen=returnScreen==='title'?'title':'play';clearKeys();audio.resume();canvas.focus();}
  function showGuide(){audio.start();modal('冒险，从一束微光开始',`<p>与村中的洛恩交谈，找回三枚萤石。它们藏在西林、河畔和旧塔的宝箱里。成长、补给，然后前往月痕遗迹。</p><div class="guide-grid"><p><kbd>WASD</kbd>移动</p><p><kbd>J / 空格</kbd>挥剑</p><p><kbd>K</kbd>萤火法术</p><p><kbd>Shift</kbd>闪避</p><p><kbd>E</kbd>对话 / 开箱</p><p><kbd>Q</kbd>治疗药水</p><p><kbd>I</kbd>背包</p><p><kbd>M</kbd>地图</p><p><kbd>Esc</kbd>暂停</p></div><div class="note">法术自动瞄准附近的敌人。留意地上的攻击预警，用闪避躲开。村庄篝火旁可以恢复生命，米娅出售药水。旅途会自动保存到当前浏览器。</div>`,'ADVENTURER’S FIELD NOTES');}
  function showPause(){if(screen!=='play')return;modal('在森林里歇一会儿','<p>旅途已保存。准备好时，微光会继续为你引路。</p>','TAKE A LITTLE BREATH');save();audio.pause();$('modal-content').append(makeButton('继续冒险 →',closeModal),makeButton('返回标题',returnTitle,'secondary'));}
  function showBag(){if(screen!=='play')return;const p=game.player;modal('旅人的行囊',`<div class="bag-grid"><div class="bag-item"><b>⚔</b><span>${p.sword?'月辉剑':'守灯人的短剑'}</span><small>已装备</small></div><div class="bag-item"><b>♜</b><span>林间药水 ×${p.potions}</span><small>恢复 60 生命</small></div><div class="bag-item"><b>◇</b><span>萤石 ×${game.stones}</span><small>任务物品</small></div></div><div class="stats"><span>等级 <b>Lv.${p.level}</b></span><span>攻击 <b>${game.damage}</b></span><span>生命 <b>${Math.ceil(p.hp)} / ${p.maxHp}</b></span><span>魔力 <b>${Math.floor(p.mp)} / ${p.maxMp}</b></span><span>经验 <b>${p.xp} / ${game.xpNeeded}</b></span><span>金币 <b>${p.coins}</b></span></div><p class="note">升级会提高攻击、生命和魔力，并恢复全部状态。月辉剑来自洛恩的委托。</p>`,'YOUR LITTLE COLLECTION');const b=makeButton('使用一瓶药水',()=>{game.potion();consumeEvents();screen='play';showBag();});b.disabled=!p.potions||p.hp>=p.maxHp;$('modal-content').append(b);}
  function showMap(){if(screen!=='play')return;modal('森林手绘地图','<canvas id="map-canvas" class="map-canvas" width="720" height="540" aria-label="地图：萤火村位于西南，桥在中央；三枚萤石在西北、北方旧塔和东南河畔；Boss在东北月痕遗迹。"></canvas><div class="map-legend"><span>✦ 你的位置</span><span>◇ 萤石宝箱</span><span>◆ 古林守卫</span></div><p class="note">唯一的过河桥梁在地图中央。三枚萤石集齐后，记得先回萤火村找洛恩。</p>','A MAP OF SMALL WONDERS');
    const m=$('map-canvas').getContext('2d'),s=720/C.W;m.fillStyle='#213d2e';m.fillRect(0,0,720,540);m.drawImage(terrain,0,0,720,540);
    m.fillStyle='#15352890';m.fillRect(0,0,720,540);
    for(const t of C.SCENERY.trees)ellipse(m,t.x*s,t.y*s,3,4,'#507047');
    const marks=[['萤火村',600,1350,'#e7d8a1'],['风语溪 · 桥',1135,820,'#c3e0cc'],['月痕遗迹',2005,415,'#e5a18b'],['暮萤林地',450,300,'#bccca1']];
    m.textAlign='center';m.font='13px "Microsoft YaHei"';for(const [name,x,y,col]of marks){m.fillStyle=col;m.fillText(name,x*s,y*s-14);}
    for(const chest of C.CHESTS.filter(c=>c.stone&&!game.opened.has(c.id))){polygon(m,[[chest.x*s,chest.y*s-7],[chest.x*s+5,chest.y*s],[chest.x*s,chest.y*s+7],[chest.x*s-5,chest.y*s]],'#f0c977');}
    const p=game.player;ellipse(m,p.x*s,p.y*s,7,7,'#e3efc0');ellipse(m,p.x*s,p.y*s,3,3,'#244936');
  }
  function showDialogue(speaker,text,choices){screen='dialogue';clearKeys();$('speaker-name').textContent=speaker;$('dialogue-text').textContent=text;$('dialogue-actions').replaceChildren();$('dialogue').hidden=false;$('interact-hint').hidden=true;
    for(const [label,fn]of choices){const b=makeButton(label,()=>{$('dialogue').hidden=true;screen='play';clearKeys();fn?.();consumeEvents();updateHUD();canvas.focus();},'');$('dialogue-actions').append(b);}requestAnimationFrame(()=>$('dialogue-actions').firstElementChild?.focus());
  }
  function interact(){if(screen!=='play')return;const item=game.interact();consumeEvents();if(!item||item.type==='loot'||item.type==='win')return;
    if(item.id==='keeper'){
      if(game.quest===0)showDialogue(item.name,'你终于回来了，小守灯人。\n古林的灯塔熄灭后，萤石散落在西边的暮萤林地、河畔和北方旧塔。找回三枚萤石，我就能为你重铸月辉剑。\n先带上村子西侧行囊里的补给。愿微光陪伴你。',[['我会把萤石带回来',()=>{game.acceptQuest();toast('任务已接取 · 按 M 查看萤石的位置',true);}]]);
      else if(game.quest===1&&game.stones<3)showDialogue(item.name,`森林会记住你的脚步。你已找到 ${game.stones} 枚萤石，还差 ${3-game.stones} 枚。\n桥在村子的东北方。走累了就回来，篝火一直为你留着。`,[['在篝火旁休息',()=>{game.rest();toast('生命与魔力已恢复');}],['我再去找找']]);
      else if(game.quest===1)showDialogue(item.name,'三枚萤石，三束失而复得的光……你做到了。\n这把月辉剑会指引你前往东北的月痕遗迹。击败被暮色侵蚀的荒根守卫，再点亮它身后的灯塔吧。\n带上这些药水。别忘了，你始终有地方可以回来。',[['接过月辉剑',()=>game.turnIn()]]);
      else showDialogue(item.name,game.quest===2?'月辉剑已经回应了你。东北方的月痕遗迹在等着你。\n守卫每次攻击前都会露出破绽，别着急，留意地面的预警。':'灯塔就在守卫身后的高处。去吧，让森林重新记起光。',[['休息并补满状态',()=>{game.rest();toast('生命与魔力已恢复');}],['告别洛恩']]);
    }else if(item.id==='merchant')showDialogue(item.name,`森林里的草药，总会留给需要它的人。\n一瓶林间药水可以恢复 60 点生命，只需 12 枚金币。你现在有 ${game.player.coins} 枚金币。`,[['购买药水 · 12 金币',()=>{if(game.buyPotion())toast('获得林间药水 ×1');}],['下次再来']]);
  }
  function showDeath(){screen='dead';modal('微光仍在等你','<div class="ending-mark">✧</div><p class="end-copy">你暂时倒在了森林里，<br>但归途的灯还没有熄灭。</p><p class="note">回到村庄时会失去 10% 金币。等级、萤石、装备和已开启的宝箱都会保留。</p>','A LIGHT NEVER TRULY FADES',false);$('modal-content').append(makeButton('在萤火村醒来 →',()=>{game.revive();screen='play';$('modal-shade').hidden=true;camera.x=game.player.x;camera.y=game.player.y;consumeEvents();updateHUD();canvas.focus();}));}
  function showEnding(){screen='win';save();modal('森林，记起了光',`<div class="ending-mark">✦</div><p class="end-copy">古老的灯塔再次亮起，<br>星火落入树梢，风带回了归途。<br><br>谢谢你，小守灯人。</p><div class="end-stats"><div><b>${game.player.level}</b><small>旅人等级</small></div><div><b>${game.kills}</b><small>击败敌人</small></div><div><b>${Math.max(1,Math.ceil(game.elapsed/60))}</b><small>冒险分钟</small></div></div>`,'CHAPTER ONE · COMPLETE',false);$('modal-content').append(makeButton('带着故事回到标题 →',returnTitle));}
  function input(){return {up:keys.KeyW||keys.ArrowUp,down:keys.KeyS||keys.ArrowDown,left:keys.KeyA||keys.ArrowLeft,right:keys.KeyD||keys.ArrowRight,attack:keys.KeyJ||keys.Space,magic:keys.KeyK};}
  function action(name){if(screen!=='play')return;audio.start();if(name==='attack')game.attack();if(name==='magic')game.cast();if(name==='dash'){const i=input();game.dash((i.right?1:0)-(i.left?1:0),(i.down?1:0)-(i.up?1:0));}if(name==='potion')game.potion();consumeEvents();updateHUD();canvas.focus();}
  $('start-btn').onclick=()=>{audio.start();if(readSave()){modal('开启新的旅程？','<p>新的冒险将覆盖当前浏览器中的旧存档。</p>','A NEW CHAPTER');$('modal-content').append(makeButton('开启新旅程',()=>startGame(false)),makeButton('保留存档，返回',closeModal,'secondary'));}else startGame(false);};
  $('continue-btn').onclick=()=>startGame(true);$('how-btn').onclick=showGuide;$('modal-close').onclick=closeModal;
  $('pause-btn').onclick=showPause;$('map-btn').onclick=showMap;$('bag-btn').onclick=showBag;
  $('sound-btn').onclick=()=>{audio.start();audio.setMuted(!audio.muted);updateSound();};
  function updateSound(){$('sound-btn').textContent=audio.muted?'♪̸':'♫';$('sound-btn').setAttribute('aria-label',audio.muted?'开启声音':'关闭声音');$('sound-btn').title=audio.muted?'开启声音':'关闭声音';}
  for(const a of ['attack','magic','dash','potion'])$(a+'-btn').onclick=()=>action(a);
  $('interact-hint').onclick=interact;$('touch-interact').onclick=interact;
  for(const b of document.querySelectorAll('[data-move]')){const code={up:'KeyW',down:'KeyS',left:'KeyA',right:'KeyD'}[b.dataset.move];b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);keys[code]=true;};b.onpointerup=b.onpointercancel=()=>{keys[code]=false;};}
  addEventListener('keydown',e=>{
    const controlled=['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','KeyW','KeyA','KeyS','KeyD','KeyJ','KeyK','KeyE','KeyQ','KeyI','KeyM','ShiftLeft','ShiftRight','Escape'];
    if(controlled.includes(e.code)&&screen!=='title')e.preventDefault();
    if(screen==='play'){keys[e.code]=true;if(e.repeat)return;if(e.code==='KeyE')interact();else if(e.code==='KeyQ')action('potion');else if(e.code.startsWith('Shift'))action('dash');else if(e.code==='KeyI')showBag();else if(e.code==='KeyM')showMap();else if(e.code==='Escape')showPause();}
    else if(screen==='dialogue'&&!e.repeat&&(e.code==='KeyE'||e.code==='Space')){$('dialogue-actions').firstElementChild?.click();}
    else if(screen==='dialogue'&&e.code==='Escape'){$('dialogue').hidden=true;screen='play';clearKeys();}
    else if(screen==='modal'&&!e.repeat&&(e.code==='Escape'||e.code==='KeyI'||e.code==='KeyM'))closeModal();
  });
  addEventListener('keyup',e=>{delete keys[e.code];});
  addEventListener('blur',()=>{clearKeys();if(screen==='play')showPause();audio.pause();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){clearKeys();if(screen==='play')showPause();save();audio.pause();}else if(screen==='title'||screen==='dialogue')audio.resume();});
  addEventListener('pagehide',()=>{if(screen!=='title')save();});
  function frame(now){
    const dt=Math.min(.05,(now-last)/1000);last=now;time+=dt;
    if(screen==='play'){game.step(dt,input());consumeEvents();saveTimer+=dt;if(saveTimer>8){save();saveTimer=0;}}
    if(screen==='title'){const targetX=width<800?680:510;camera.x+=(targetX+Math.sin(time*.1)*12-camera.x)*.035;camera.y+=(1200+Math.cos(time*.1)*10-camera.y)*.035;}
    else {const vw=width/scale/2,vh=height/scale/2;const tx=C.clamp(game.player.x,Math.min(vw,C.W/2),Math.max(C.W/2,C.W-vw)),ty=C.clamp(game.player.y,Math.min(vh,C.H/2),Math.max(C.H/2,C.H-vh));camera.x+=(tx-camera.x)*(1-Math.exp(-dt*9));camera.y+=(ty-camera.y)*(1-Math.exp(-dt*9));}
    if(screen==='play'||screen==='title'){
      for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=55*dt;if(p.life<=0)particles.splice(i,1);}
      for(let i=floats.length-1;i>=0;i--){floats[i].life-=dt;floats[i].y-=25*dt;if(floats[i].life<=0)floats.splice(i,1);}
    }
    shake=Math.max(0,shake-dt*20);audio.update();drawWorld();hudTimer+=dt;if(screen!=='title'&&hudTimer>.08){updateHUD();hudTimer=0;}
    requestAnimationFrame(frame);
  }
  updateContinue();updateSound();requestAnimationFrame(frame);
})();
